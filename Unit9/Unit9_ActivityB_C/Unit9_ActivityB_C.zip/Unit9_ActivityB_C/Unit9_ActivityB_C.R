# Teammates/Group: Diana Salinas, Ethan, Trevor
# October 7, 2022
# Activity 9 B and C

rm(list = ls())
# install.packages("tidyverse")
# install.packages("RColorBrewer")
# install.packages("productplots")
# install.packages("pacman")
# install.packages("reshape2")
# install.packages("rvest")

pacman::p_load(tidyverse, RColorBrewer, productplots,reshape2, rvest)
library(tidyverse)
library(rvest)
library(RColorBrewer)

ff <- french_fries

ff <- ff %>% 
  pivot_longer(5:9, names_to = "category", values_to = "amount", values_drop_na = TRUE)

ffca <- ff %>%
  group_by(category) %>%
  summarise(mean(amount)) %>%
  arrange(`mean(amount)`)

ffca %>% ggplot() +
  geom_col(aes(x=reorder(category, `mean(amount)`), y=`mean(amount)`, fill=category)) +
  coord_flip() +
  labs(title = "French Fries") +
  theme(axis.title.y = element_blank(), plot.title = element_text(hjust=0.5))

############## 


imdb_top_250 <- dir(path = "data", pattern = "*.csv") %>% 
  map_dfr(function(x) read_csv(file.path("data", x)))

color1 <- c(brewer.pal(9, "Set1"))

imdb_top_250 %>% 
  ggplot() +
  ggtitle("Top 250 Grossing Movies") +
  theme(plot.title = element_text(hjust = 0.5)) +
  labs(y = "Dollars in Millions", x = "Year") +
  geom_histogram(mapping = aes(x = year), fill = color1, bins = 9) +
  theme(panel.background = element_blank())






